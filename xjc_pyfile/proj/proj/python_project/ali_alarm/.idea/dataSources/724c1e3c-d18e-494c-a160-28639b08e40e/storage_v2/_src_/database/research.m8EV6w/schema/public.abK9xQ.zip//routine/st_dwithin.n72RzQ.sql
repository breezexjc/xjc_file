create function st_dwithin(text, text, double precision)
  returns boolean
immutable
parallel safe
language sql
as $$
SELECT ST_DWithin($1::public.geometry, $2::public.geometry, $3);
$$;

