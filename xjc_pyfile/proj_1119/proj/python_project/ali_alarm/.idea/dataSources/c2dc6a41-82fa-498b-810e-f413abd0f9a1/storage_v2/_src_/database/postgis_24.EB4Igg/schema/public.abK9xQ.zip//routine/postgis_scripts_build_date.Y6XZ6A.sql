create function postgis_scripts_build_date()
  returns text
immutable
language sql
as $$
SELECT '2018-04-06 10:14:06'::text AS version
$$;

comment on function postgis_scripts_build_date()
is 'Returns build date of the PostGIS scripts.';

