create function st_reclass(rast raster, nband integer, reclassexpr text, pixeltype text, nodataval double precision DEFAULT NULL::double precision)
  returns raster
immutable
parallel safe
language sql
as $$
SELECT st_reclass($1, ROW($2, $3, $4, $5))
$$;

