create function st_transscale(geometry, double precision, double precision, double precision, double precision)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT public.ST_Affine($1,  $4, 0, 0,  0, $5, 0,
		0, 0, 1,  $2 * $4, $3 * $5, 0)
$$;

comment on function st_transscale(geometry, double precision, double precision, double precision, double precision)
is 'args: geomA, deltaX, deltaY, XFactor, YFactor - Translate a geometry by given factors and offsets.';

