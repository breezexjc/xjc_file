create function st_asbinary(geography, text)
  returns bytea
immutable
strict
parallel safe
language sql
as $$
SELECT public.ST_AsBinary($1::public.geometry, $2);
$$;

comment on function st_asbinary(geography, text)
is 'args: g1, NDR_or_XDR - Return the Well-Known Binary (WKB) representation of the geometry/geography without SRID meta data.';

