create function st_asgeojson(gj_version integer, geog geography, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0)
  returns text
immutable
strict
parallel safe
language sql
as $$
SELECT public._ST_AsGeoJson($1, $2, $3, $4);
$$;

comment on function st_asgeojson(gj_version integer, geog geography, maxdecimaldigits integer DEFAULT 15,
                                 options    integer DEFAULT 0)
is 'args: gj_version, geog, maxdecimaldigits=15, options=0 - Return the geometry as a GeoJSON element.';

