from proj.python_project.scats_interface.data_request_check import InterfaceCheck



if __name__ == "__main__":
    I = InterfaceCheck()
    # I.salk_list_request()
    I.operate_request()
