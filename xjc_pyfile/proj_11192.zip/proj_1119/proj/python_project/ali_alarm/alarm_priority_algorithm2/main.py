from proj.proj.python_project.ali_alarm.alarm_priority_algorithm2.alarm_data_regular_filter import create_process

if __name__ == '__main__':
    create_process()