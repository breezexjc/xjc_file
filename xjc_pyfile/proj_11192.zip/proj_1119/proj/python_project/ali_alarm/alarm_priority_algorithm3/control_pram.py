IF_TEST = False
TD = 30
TA = 16
TW = 16
TRD = 10
TEXT_DATE = '2018-10-12 09:44:00'
####################
TEST_DAY = '2018-11-14'