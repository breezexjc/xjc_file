dataBase = "sms"
user = "postgres"
password = "postgres"
host = "192.168.20.46"
port = 5432