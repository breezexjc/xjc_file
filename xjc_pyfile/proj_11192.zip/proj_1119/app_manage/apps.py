from django.apps import AppConfig


class AppManageConfig(AppConfig):
    name = 'app_manage'
